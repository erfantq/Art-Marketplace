import { createContext } from "react"

const ThemeContext = createContext('dark')