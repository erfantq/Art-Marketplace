import React from 'react'

export default function Buy() {
  return (
    <div>Buy</div>
  )
}
