import React from "react";
import Signup from "./components/Register";

function App() {
  return (
    <div className="App">
      <Signup />
    </div>
  );
}

export default App;
